﻿using ApexSole_Sneakers.Models;

namespace ApexSole_Sneakers.ViewModels
{
    public class DashboardViewModel
    {
        public List<Sneakers> Sneakers { get; set; }
        public List<Tshirt> Tshirts { get; set; }
    }
}
