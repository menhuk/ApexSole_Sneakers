﻿namespace ApexSole_Sneakers.Data.Enum
{
    public enum TshirtType
    {
        Sleeveless,
        LongSleeve,
        RaglanSleeve,
        Heavyweight
    }
}
