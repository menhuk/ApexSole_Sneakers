﻿using ApexSole_Sneakers.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace ApexSole_Sneakers.Data
{
    public class ApplicationDbContext: IdentityDbContext<AppUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) 
        {
        
        }
        public DbSet<Sneakers> Sneakers { get; set; }
        public DbSet<Jeans> Jeans { get; set; }
        public DbSet<Jacket> Jackets { get; set; }
        public DbSet<Tshirt> Tshirts { get; set; }
        public DbSet<Apparel> Apparel { get; set; }
        public DbSet<ShoppingCart> ShoppingCarts { get; set; }
        public DbSet<OrderHead> OrderHeads { get; set; }
        public DbSet<OrderInfo> OrderInfos { get; set; }

    }
}
