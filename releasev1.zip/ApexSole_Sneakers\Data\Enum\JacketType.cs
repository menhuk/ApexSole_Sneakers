﻿namespace ApexSole_Sneakers.Data.Enum
{
    public enum JacketType
    {
        BomberJacket,
        FlightJacket,
        LeatherJacket,
        VarsityJacket,
        PufferJacket,
        HarringtonJacket
    }
}
