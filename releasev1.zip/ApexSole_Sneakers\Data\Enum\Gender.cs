﻿namespace ApexSole_Sneakers.Data.Enum
{
    public enum Gender
    {
        Wonem,
        Man
    }
}
