﻿namespace ApexSole_Sneakers.Data.Enum
{
    public enum JeansType
    {
        SlimFit,
        Straight,
        Skinny,
        WideLeg
    }
}
