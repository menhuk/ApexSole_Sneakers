﻿namespace ApexSole_Sneakers.Data.Enum
{
    public enum SneakersType
    {
        HighTopSneakers,
        SlipOnSneakers,
        SyntheticSneakers,
        AthleticSneakers,
        RetroSnakers,
        SkateSneakers,
        DesignerSneakers
    }
}
